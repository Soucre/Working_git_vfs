<?php

//KEYS
define(PAGE_TITLE, "page-title");
define(PAGE, "page");
define(MEMBER_ID, "member-id");
define(MEMBER_EMAIL, "member-email");
define(MEMBER_DISPLAY_NAME, "member-display-name");
define(MEMBER_PICTURE, "member-picture");
define(MEMBER_SINCE, "member-since");
define(MEMBER_LOG_IN_MSG, "member-log-in-msg");
define(MEMBER_ROLE, "member-role");
define(MEMBER_REMEMBER_ME, "member-remember-me");
define(APPLICATION_ERROR_CODE, "application-error-code");
define(APPLICATION_MESSAGE, "application-message");
define(APPLICATION_MESSAGE_TYPE, "application-message-type");
define(SETTINGS_DATE_FORMAT, "settings-date-format");
define(APPLICATION_NAME, "application-name");
define(COMPANY, "company");
define(SLOGAN, "slogan");
define(WEBSITE, "website");
define(COPY_RIGHTS, "copy_rights");
define(LOGO_MINI, "logo-mini");
define(LOGO_LG, "logo-lg");
define(APPLICATION_DEFAULT_MODULE_NAME, "default-module-name");


/**
 * Database - MySQL account
 */
define(MY_SQL_HOST, "localhost");
define(MY_SQL_USER, "root");
define(MY_SQL_PASSWORD, "SPRZ@JannPaul@oi5");
define(MY_SQL_DATABASE, "jannpaul");

// Default role
define(APPLICATION_ROLE_ADMINISTRATOR, "Administrator");